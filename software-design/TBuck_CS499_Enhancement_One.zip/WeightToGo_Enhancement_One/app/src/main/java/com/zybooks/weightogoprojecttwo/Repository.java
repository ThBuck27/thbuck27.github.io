package com.zybooks.weightogoprojecttwo;

import android.content.Context;
import java.util.List;

/**
 * Provides a single access point for application database operations.
 */
public class Repository {

    private final DatabaseHelper databaseHelper;

    public Repository(Context context) {
        databaseHelper = new DatabaseHelper(context.getApplicationContext());
    }

    public boolean validateUser(String username, String password) {
        return databaseHelper.validateUser(username, password);
    }

    public boolean registerUser(String username, String password) {
        return databaseHelper.registerUser(username, password);
    }

    public Double getGoalWeight(String username) {
        return databaseHelper.getGoalWeight(username);
    }

    public void saveGoalWeight(String username, double goalWeight) {
        databaseHelper.saveGoalWeight(username, goalWeight);
    }

    public List<WeightEntry> getWeightEntries(String username) {
        return databaseHelper.getAllWeightEntriesForUser(username);
    }

    public boolean deleteWeightEntry(int entryId) {
        return databaseHelper.deleteWeightEntry(entryId) > 0;
    }

    public boolean addWeightEntry(
            String username,
            String entryDate,
            double weightValue
    ) {
        return databaseHelper.addWeightEntry(
                username,
                entryDate,
                weightValue
        ) != -1;
    }

    public boolean updateWeightEntry(
            int entryId,
            String entryDate,
            double weightValue
    ) {
        return databaseHelper.updateWeightEntry(
                entryId,
                entryDate,
                weightValue
        ) > 0;
    }

    public String getPhoneNumber(String username) {
        return databaseHelper.getPhoneNumber(username);
    }

    public void savePhoneNumber(String username, String phoneNumber) {
        databaseHelper.savePhoneNumber(username, phoneNumber);
    }
}