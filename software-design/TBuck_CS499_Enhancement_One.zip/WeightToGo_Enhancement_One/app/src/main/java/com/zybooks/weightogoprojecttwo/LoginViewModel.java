package com.zybooks.weightogoprojecttwo;

import android.content.Context;

/**
 * Handles validation and account logic for the login screen.
 */
public class LoginViewModel {

    private final Repository repository;

    public LoginViewModel(Context context) {
        repository = new Repository(context);
    }

    public String validateCredentials(String username, String password) {
        if (username == null || username.trim().isEmpty()
                || password == null || password.trim().isEmpty()) {
            return "Enter both username and password.";
        }

        return null;
    }

    public boolean login(String username, String password) {
        return repository.validateUser(username.trim(), password.trim());
    }

    public boolean createAccount(String username, String password) {
        return repository.registerUser(username.trim(), password.trim());
    }
}