package com.zybooks.weightogoprojecttwo;

import android.Manifest;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.ContextCompat;

/**
 * Allows the user to save a phone number and request SMS permission.
 */
public class SmsPermissionActivity extends AppCompatActivity {

    private SmsSettingsViewModel smsSettingsViewModel;
    private String username;

    private TextView textPermissionStatus;
    private EditText editPhoneNumber;

    private ActivityResultLauncher<String> smsPermissionLauncher;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sms_permission);

        smsSettingsViewModel = new SmsSettingsViewModel(this);
        username = getIntent().getStringExtra("USERNAME");

        textPermissionStatus = findViewById(R.id.textPermissionStatus);
        editPhoneNumber = findViewById(R.id.editPhoneNumber);
        Button buttonSavePhone = findViewById(R.id.buttonSavePhone);
        Button buttonRequestSmsPermission = findViewById(R.id.buttonRequestSmsPermission);
        Button buttonBackToDashboard = findViewById(R.id.buttonBackToDashboard);

        String savedPhoneNumber =
                smsSettingsViewModel.getSavedPhoneNumber(username);

        editPhoneNumber.setText(savedPhoneNumber);

        smsPermissionLauncher = registerForActivityResult(
                new ActivityResultContracts.RequestPermission(),
                isGranted -> {
                    updatePermissionStatus();
                    if (isGranted) {
                        Toast.makeText(this, "SMS permission granted.", Toast.LENGTH_SHORT).show();
                    } else {
                        Toast.makeText(this, "SMS permission denied. The app will still work without alerts.", Toast.LENGTH_LONG).show();
                    }
                }
        );

        updatePermissionStatus();

        buttonSavePhone.setOnClickListener(v -> savePhoneNumber());
        buttonRequestSmsPermission.setOnClickListener(v -> requestSmsPermission());
        buttonBackToDashboard.setOnClickListener(v -> finish());
    }

    private void savePhoneNumber() {
        String phoneNumber =
                editPhoneNumber.getText().toString();

        String validationMessage =
                smsSettingsViewModel.validatePhoneNumber(phoneNumber);

        if (validationMessage != null) {
            Toast.makeText(
                    this,
                    validationMessage,
                    Toast.LENGTH_SHORT
            ).show();
            return;
        }

        smsSettingsViewModel.savePhoneNumber(
                username,
                phoneNumber
        );

        Toast.makeText(
                this,
                "Phone number saved.",
                Toast.LENGTH_SHORT
        ).show();
    }

    private void requestSmsPermission() {
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.SEND_SMS)
                == PackageManager.PERMISSION_GRANTED) {
            Toast.makeText(this, "SMS permission is already granted.", Toast.LENGTH_SHORT).show();
            updatePermissionStatus();
        } else {
            smsPermissionLauncher.launch(Manifest.permission.SEND_SMS);
        }
    }

    private void updatePermissionStatus() {
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.SEND_SMS)
                == PackageManager.PERMISSION_GRANTED) {
            textPermissionStatus.setText("SMS permission granted");
        } else {
            textPermissionStatus.setText("SMS permission denied");
        }
    }
}