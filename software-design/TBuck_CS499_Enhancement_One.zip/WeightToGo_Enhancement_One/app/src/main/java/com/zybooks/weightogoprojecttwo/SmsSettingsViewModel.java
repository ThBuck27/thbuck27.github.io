package com.zybooks.weightogoprojecttwo;

import android.content.Context;

/**
 * Handles phone-number validation and storage for SMS settings.
 */
public class SmsSettingsViewModel {

    private final Repository repository;

    public SmsSettingsViewModel(Context context) {
        repository = new Repository(context);
    }

    public String getSavedPhoneNumber(String username) {
        String phoneNumber = repository.getPhoneNumber(username);

        if (phoneNumber == null) {
            return "";
        }

        return phoneNumber;
    }

    public String validatePhoneNumber(String phoneNumber) {
        if (phoneNumber == null || phoneNumber.trim().isEmpty()) {
            return "Enter a phone number.";
        }

        String cleanedNumber =
                phoneNumber.replaceAll("[^0-9]", "");

        if (cleanedNumber.length() < 10
                || cleanedNumber.length() > 15) {
            return "Enter a valid phone number.";
        }

        return null;
    }

    public void savePhoneNumber(
            String username,
            String phoneNumber
    ) {
        repository.savePhoneNumber(
                username,
                phoneNumber.trim()
        );
    }
}