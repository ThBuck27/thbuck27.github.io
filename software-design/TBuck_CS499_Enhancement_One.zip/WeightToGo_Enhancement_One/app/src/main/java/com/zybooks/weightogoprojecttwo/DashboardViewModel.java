package com.zybooks.weightogoprojecttwo;

import android.content.Context;
import java.util.List;
import java.util.Locale;

/**
 * Handles goal-weight logic for the dashboard screen.
 */
public class DashboardViewModel {

    private final Repository repository;

    public DashboardViewModel(Context context) {
        repository = new Repository(context);
    }

    public String getGoalDisplay(String username) {
        Double goal = repository.getGoalWeight(username);

        if (goal == null) {
            return "No goal weight set";
        }

        return String.format(Locale.US, "%.1f lbs", goal);
    }

    public String validateGoalWeight(String goalText) {
        if (goalText == null || goalText.trim().isEmpty()) {
            return "Enter a goal weight.";
        }

        try {
            double goalWeight = Double.parseDouble(goalText.trim());

            if (goalWeight <= 0) {
                return "Goal weight must be greater than zero.";
            }
        } catch (NumberFormatException exception) {
            return "Enter a valid number.";
        }

        return null;
    }

    public void saveGoalWeight(String username, String goalText) {
        double goalWeight = Double.parseDouble(goalText.trim());
        repository.saveGoalWeight(username, goalWeight);
    }

    public List<WeightEntry> getWeightEntries(String username) {
        return repository.getWeightEntries(username);
    }

    public boolean deleteWeightEntry(int entryId) {
        return repository.deleteWeightEntry(entryId);
    }
}