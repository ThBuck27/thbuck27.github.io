package com.zybooks.weightogoprojecttwo;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

/**
 * Handles user login and first-time account creation.
 */
public class LoginActivity extends AppCompatActivity {

    private EditText editUsername;
    private EditText editPassword;
    private LoginViewModel loginViewModel;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        loginViewModel = new LoginViewModel(this);

        editUsername = findViewById(R.id.editUsername);
        editPassword = findViewById(R.id.editPassword);
        Button buttonLogin = findViewById(R.id.buttonLogin);
        Button buttonCreateAccount = findViewById(R.id.buttonCreateAccount);

        buttonLogin.setOnClickListener(v -> attemptLogin());
        buttonCreateAccount.setOnClickListener(v -> attemptCreateAccount());
    }

    private void attemptLogin() {
        String username = editUsername.getText().toString();
        String password = editPassword.getText().toString();

        String validationMessage =
                loginViewModel.validateCredentials(username, password);

        if (validationMessage != null) {
            Toast.makeText(this, validationMessage, Toast.LENGTH_SHORT).show();
            return;
        }

        if (loginViewModel.login(username, password)) {
            openDashboard(username.trim());
        } else {
            Toast.makeText(
                    this,
                    "Login failed. Check your username and password.",
                    Toast.LENGTH_SHORT
            ).show();
        }
    }

    private void attemptCreateAccount() {
        String username = editUsername.getText().toString();
        String password = editPassword.getText().toString();

        String validationMessage =
                loginViewModel.validateCredentials(username, password);

        if (validationMessage != null) {
            Toast.makeText(this, validationMessage, Toast.LENGTH_SHORT).show();
            return;
        }

        boolean created = loginViewModel.createAccount(username, password);

        if (created) {
            Toast.makeText(
                    this,
                    "Account created successfully.",
                    Toast.LENGTH_SHORT
            ).show();

            openDashboard(username.trim());
        } else {
            Toast.makeText(
                    this,
                    "That username already exists.",
                    Toast.LENGTH_SHORT
            ).show();
        }
    }

    private void openDashboard(String username) {
        Intent intent = new Intent(this, DashboardActivity.class);
        intent.putExtra("USERNAME", username);
        startActivity(intent);
    }
}