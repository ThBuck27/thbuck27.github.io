package com.zybooks.weightogoprojecttwo;

import android.Manifest;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.telephony.SmsManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.ContextCompat;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

/**
 * Handles adding a new daily weight or editing an existing one.
 */
public class AddWeightActivity extends AppCompatActivity {

    private EditText editWeightValue;
    private EditText editWeightDate;
    private AddWeightViewModel addWeightViewModel;
    private String username;
    private int entryId = -1;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_weight);

        addWeightViewModel = new AddWeightViewModel(this);

        editWeightValue = findViewById(R.id.editWeightValue);
        editWeightDate = findViewById(R.id.editWeightDate);
        Button buttonSaveWeight = findViewById(R.id.buttonSaveWeight);
        Button buttonCancelWeight = findViewById(R.id.buttonCancelWeight);

        username = getIntent().getStringExtra("USERNAME");

        if (getIntent().hasExtra("ENTRY_ID")) {
            entryId = getIntent().getIntExtra("ENTRY_ID", -1);
            String existingDate = getIntent().getStringExtra("ENTRY_DATE");
            double existingWeight = getIntent().getDoubleExtra("ENTRY_WEIGHT", 0.0);

            editWeightDate.setText(existingDate);
            editWeightValue.setText(String.valueOf(existingWeight));
        } else {
            String today = new SimpleDateFormat("yyyy-MM-dd", Locale.US).format(new Date());
            editWeightDate.setText(today);
        }

        buttonSaveWeight.setOnClickListener(v -> saveWeight());
        buttonCancelWeight.setOnClickListener(v -> finish());
    }

    private void saveWeight() {
        String weightText =
                editWeightValue.getText().toString();
        String dateText =
                editWeightDate.getText().toString();
        String validationMessage =
                addWeightViewModel.validateWeightEntry(
                        weightText,
                        dateText
                );
        if (validationMessage != null) {
            Toast.makeText(
                    this,
                    validationMessage,
                    Toast.LENGTH_SHORT
            ).show();
            return;
        }
        boolean isNewEntry = entryId == -1;

        boolean saved =
                addWeightViewModel.saveWeightEntry(
                        entryId,
                        username,
                        dateText,
                        weightText
                );
        if (!saved) {
            Toast.makeText(
                    this,
                    "Unable to save weight entry.",
                    Toast.LENGTH_SHORT
            ).show();
            return;
        }
        double weightValue =
                Double.parseDouble(weightText.trim());
        if (isNewEntry) {
            Toast.makeText(
                    this,
                    "Weight entry added.",
                    Toast.LENGTH_SHORT
            ).show();
        } else {
            Toast.makeText(
                    this,
                    "Weight entry updated.",
                    Toast.LENGTH_SHORT
            ).show();
        }
        checkGoalAndSendSms(weightValue);
        setResult(RESULT_OK);
        finish();
    }

    private void checkGoalAndSendSms(double savedWeight) {
        boolean goalReached =
                addWeightViewModel.isGoalReached(
                        username,
                        savedWeight
                );

        if (!goalReached) {
            return;
        }

        Double goalWeight =
                addWeightViewModel.getGoalWeight(username);

        if (goalWeight == null) {
            return;
        }

        if (ContextCompat.checkSelfPermission(this, Manifest.permission.SEND_SMS)
                != PackageManager.PERMISSION_GRANTED) {
            return;
        }

        String phoneNumber =
                addWeightViewModel.getPhoneNumber(username);
        if (phoneNumber == null || phoneNumber.trim().isEmpty()) {
            return;
        }

        try {
            SmsManager smsManager = SmsManager.getDefault();
            String message = String.format(
                    Locale.US,
                    "Weigh to Go! Goal reached. You logged %.1f and matched your goal of %.1f.",
                    savedWeight,
                    goalWeight
            );
            smsManager.sendTextMessage(phoneNumber, null, message, null, null);
            Toast.makeText(this, "Goal reached. SMS alert sent.", Toast.LENGTH_LONG).show();
        } catch (Exception ex) {
            Toast.makeText(this, "Goal reached, but SMS could not be sent.", Toast.LENGTH_LONG).show();
        }
    }
}