package com.zybooks.weightogoprojecttwo;

import android.content.Context;

/**
 * Handles validation and saving logic for weight entries.
 */
public class AddWeightViewModel {

    private final Repository repository;

    public AddWeightViewModel(Context context) {
        repository = new Repository(context);
    }

    public String validateWeightEntry(
            String weightText,
            String dateText
    ) {
        if (weightText == null
                || weightText.trim().isEmpty()
                || dateText == null
                || dateText.trim().isEmpty()) {
            return "Enter both a weight and date.";
        }

        try {
            double weightValue =
                    Double.parseDouble(weightText.trim());

            if (weightValue <= 0) {
                return "Weight must be greater than zero.";
            }
        } catch (NumberFormatException exception) {
            return "Enter a valid weight value.";
        }

        return null;
    }

    public boolean saveWeightEntry(
            int entryId,
            String username,
            String dateText,
            String weightText
    ) {
        double weightValue =
                Double.parseDouble(weightText.trim());

        if (entryId == -1) {
            return repository.addWeightEntry(
                    username,
                    dateText.trim(),
                    weightValue
            );
        }

        return repository.updateWeightEntry(
                entryId,
                dateText.trim(),
                weightValue
        );
    }

    public boolean isGoalReached(
            String username,
            double savedWeight
    ) {
        Double goalWeight =
                repository.getGoalWeight(username);

        if (goalWeight == null) {
            return false;
        }

        return Math.abs(savedWeight - goalWeight) <= 0.1;
    }

    public Double getGoalWeight(String username) {
        return repository.getGoalWeight(username);
    }

    public String getPhoneNumber(String username) {
        return repository.getPhoneNumber(username);
    }
}