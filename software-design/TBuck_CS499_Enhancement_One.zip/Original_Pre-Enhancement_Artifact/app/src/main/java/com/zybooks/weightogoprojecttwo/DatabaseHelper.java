package com.zybooks.weightogoprojecttwo;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import java.util.ArrayList;
import java.util.List;

/**
 * Central database helper for Weigh to Go!.
 */
public class DatabaseHelper extends SQLiteOpenHelper {

    private static final String DATABASE_NAME = "weigh_to_go.db";
    private static final int DATABASE_VERSION = 1;

    private static final String TABLE_USERS = "users";
    private static final String USER_ID = "id";
    private static final String USERNAME = "username";
    private static final String PASSWORD = "password";
    private static final String PHONE_NUMBER = "phone_number";

    private static final String TABLE_GOALS = "goal_weights";
    private static final String GOAL_ID = "id";
    private static final String GOAL_USERNAME = "username";
    private static final String GOAL_WEIGHT = "goal_weight";

    private static final String TABLE_WEIGHTS = "daily_weights";
    private static final String WEIGHT_ID = "id";
    private static final String WEIGHT_USERNAME = "username";
    private static final String ENTRY_DATE = "entry_date";
    private static final String WEIGHT_VALUE = "weight_value";

    public DatabaseHelper(Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        String createUsersTable = "CREATE TABLE " + TABLE_USERS + " ("
                + USER_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, "
                + USERNAME + " TEXT UNIQUE, "
                + PASSWORD + " TEXT, "
                + PHONE_NUMBER + " TEXT)";

        String createGoalsTable = "CREATE TABLE " + TABLE_GOALS + " ("
                + GOAL_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, "
                + GOAL_USERNAME + " TEXT UNIQUE, "
                + GOAL_WEIGHT + " REAL)";

        String createWeightsTable = "CREATE TABLE " + TABLE_WEIGHTS + " ("
                + WEIGHT_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, "
                + WEIGHT_USERNAME + " TEXT, "
                + ENTRY_DATE + " TEXT, "
                + WEIGHT_VALUE + " REAL)";

        db.execSQL(createUsersTable);
        db.execSQL(createGoalsTable);
        db.execSQL(createWeightsTable);
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_USERS);
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_GOALS);
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_WEIGHTS);
        onCreate(db);
    }

    public boolean registerUser(String username, String password) {
        if (userExists(username)) {
            return false;
        }

        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(USERNAME, username);
        values.put(PASSWORD, password);
        values.put(PHONE_NUMBER, "");

        long result = db.insert(TABLE_USERS, null, values);
        return result != -1;
    }

    public boolean userExists(String username) {
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.rawQuery(
                "SELECT * FROM " + TABLE_USERS + " WHERE " + USERNAME + " = ?",
                new String[]{username}
        );

        boolean exists = cursor.getCount() > 0;
        cursor.close();
        return exists;
    }

    public boolean validateUser(String username, String password) {
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.rawQuery(
                "SELECT * FROM " + TABLE_USERS + " WHERE " + USERNAME + " = ? AND " + PASSWORD + " = ?",
                new String[]{username, password}
        );

        boolean valid = cursor.getCount() > 0;
        cursor.close();
        return valid;
    }

    public void saveGoalWeight(String username, double goalWeight) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(GOAL_USERNAME, username);
        values.put(GOAL_WEIGHT, goalWeight);

        db.insertWithOnConflict(TABLE_GOALS, null, values, SQLiteDatabase.CONFLICT_REPLACE);
    }

    public Double getGoalWeight(String username) {
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.rawQuery(
                "SELECT " + GOAL_WEIGHT + " FROM " + TABLE_GOALS + " WHERE " + GOAL_USERNAME + " = ?",
                new String[]{username}
        );

        Double goal = null;
        if (cursor.moveToFirst()) {
            goal = cursor.getDouble(0);
        }
        cursor.close();
        return goal;
    }

    public void savePhoneNumber(String username, String phoneNumber) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(PHONE_NUMBER, phoneNumber);

        db.update(TABLE_USERS, values, USERNAME + " = ?", new String[]{username});
    }

    public String getPhoneNumber(String username) {
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.rawQuery(
                "SELECT " + PHONE_NUMBER + " FROM " + TABLE_USERS + " WHERE " + USERNAME + " = ?",
                new String[]{username}
        );

        String phone = "";
        if (cursor.moveToFirst()) {
            phone = cursor.getString(0);
        }
        cursor.close();
        return phone;
    }

    public long addWeightEntry(String username, String entryDate, double weightValue) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(WEIGHT_USERNAME, username);
        values.put(ENTRY_DATE, entryDate);
        values.put(WEIGHT_VALUE, weightValue);

        return db.insert(TABLE_WEIGHTS, null, values);
    }

    public int updateWeightEntry(int id, String entryDate, double weightValue) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(ENTRY_DATE, entryDate);
        values.put(WEIGHT_VALUE, weightValue);

        return db.update(TABLE_WEIGHTS, values, WEIGHT_ID + " = ?", new String[]{String.valueOf(id)});
    }

    public int deleteWeightEntry(int id) {
        SQLiteDatabase db = this.getWritableDatabase();
        return db.delete(TABLE_WEIGHTS, WEIGHT_ID + " = ?", new String[]{String.valueOf(id)});
    }

    public List<WeightEntry> getAllWeightEntriesForUser(String username) {
        List<WeightEntry> entries = new ArrayList<>();
        SQLiteDatabase db = this.getReadableDatabase();

        Cursor cursor = db.rawQuery(
                "SELECT " + WEIGHT_ID + ", " + ENTRY_DATE + ", " + WEIGHT_VALUE
                        + " FROM " + TABLE_WEIGHTS
                        + " WHERE " + WEIGHT_USERNAME + " = ?"
                        + " ORDER BY " + ENTRY_DATE + " DESC",
                new String[]{username}
        );

        if (cursor.moveToFirst()) {
            do {
                int id = cursor.getInt(0);
                String date = cursor.getString(1);
                double value = cursor.getDouble(2);
                entries.add(new WeightEntry(id, date, value));
            } while (cursor.moveToNext());
        }

        cursor.close();
        return entries;
    }
}