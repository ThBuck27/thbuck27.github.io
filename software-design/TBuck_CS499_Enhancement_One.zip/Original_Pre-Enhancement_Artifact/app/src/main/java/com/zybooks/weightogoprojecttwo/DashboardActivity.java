package com.zybooks.weightogoprojecttwo;

import android.app.AlertDialog;
import android.content.Intent;
import android.os.Bundle;
import android.text.InputType;
import android.view.Gravity;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TableLayout;
import android.widget.TableRow;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.appcompat.app.AppCompatActivity;

import java.util.List;
import java.util.Locale;

/**
 * Main dashboard screen for viewing, adding, editing, and deleting weight entries.
 */
public class DashboardActivity extends AppCompatActivity {

    private DatabaseHelper databaseHelper;
    private String username;

    private TextView textWelcomeUser;
    private TextView textGoalValue;
    private TableLayout tableWeights;

    private ActivityResultLauncher<Intent> addEditLauncher;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_dashboard);

        databaseHelper = new DatabaseHelper(this);
        username = getIntent().getStringExtra("USERNAME");

        textWelcomeUser = findViewById(R.id.textWelcomeUser);
        textGoalValue = findViewById(R.id.textGoalValue);
        tableWeights = findViewById(R.id.tableWeights);

        Button buttonSetGoal = findViewById(R.id.buttonSetGoal);
        Button buttonAddWeight = findViewById(R.id.buttonAddWeight);
        Button buttonSmsSettings = findViewById(R.id.buttonSmsSettings);
        Button buttonLogout = findViewById(R.id.buttonLogout);

        textWelcomeUser.setText("Welcome, " + username);

        addEditLauncher = registerForActivityResult(
                new ActivityResultContracts.StartActivityForResult(),
                result -> {
                    if (result.getResultCode() == RESULT_OK) {
                        refreshGoalDisplay();
                        populateWeightTable();
                    }
                }
        );

        buttonSetGoal.setOnClickListener(v -> showSetGoalDialog());
        buttonAddWeight.setOnClickListener(v -> openAddWeightScreen());
        buttonSmsSettings.setOnClickListener(v -> openSmsSettingsScreen());
        buttonLogout.setOnClickListener(v -> finish());

        refreshGoalDisplay();
        populateWeightTable();
    }

    private void refreshGoalDisplay() {
        Double goal = databaseHelper.getGoalWeight(username);
        if (goal == null) {
            textGoalValue.setText("No goal weight set");
        } else {
            textGoalValue.setText(String.format(Locale.US, "%.1f lbs", goal));
        }
    }

    private void showSetGoalDialog() {
        EditText input = new EditText(this);
        input.setHint("Enter goal weight");
        input.setInputType(InputType.TYPE_CLASS_NUMBER | InputType.TYPE_NUMBER_FLAG_DECIMAL);
        input.setPadding(40, 30, 40, 30);

        new AlertDialog.Builder(this)
                .setTitle("Set Goal Weight")
                .setView(input)
                .setPositiveButton("Save", (dialog, which) -> {
                    String value = input.getText().toString().trim();
                    if (value.isEmpty()) {
                        Toast.makeText(this, "Enter a goal weight.", Toast.LENGTH_SHORT).show();
                        return;
                    }

                    try {
                        double goal = Double.parseDouble(value);
                        databaseHelper.saveGoalWeight(username, goal);
                        refreshGoalDisplay();
                        Toast.makeText(this, "Goal weight saved.", Toast.LENGTH_SHORT).show();
                    } catch (NumberFormatException ex) {
                        Toast.makeText(this, "Enter a valid number.", Toast.LENGTH_SHORT).show();
                    }
                })
                .setNegativeButton("Cancel", null)
                .show();
    }

    private void openAddWeightScreen() {
        Intent intent = new Intent(this, AddWeightActivity.class);
        intent.putExtra("USERNAME", username);
        addEditLauncher.launch(intent);
    }

    private void openEditWeightScreen(WeightEntry entry) {
        Intent intent = new Intent(this, AddWeightActivity.class);
        intent.putExtra("USERNAME", username);
        intent.putExtra("ENTRY_ID", entry.getId());
        intent.putExtra("ENTRY_DATE", entry.getEntryDate());
        intent.putExtra("ENTRY_WEIGHT", entry.getWeightValue());
        addEditLauncher.launch(intent);
    }

    private void openSmsSettingsScreen() {
        Intent intent = new Intent(this, SmsPermissionActivity.class);
        intent.putExtra("USERNAME", username);
        startActivity(intent);
    }

    private void populateWeightTable() {
        while (tableWeights.getChildCount() > 1) {
            tableWeights.removeViewAt(1);
        }

        List<WeightEntry> entries = databaseHelper.getAllWeightEntriesForUser(username);

        if (entries.isEmpty()) {
            TableRow emptyRow = new TableRow(this);
            TextView emptyText = new TextView(this);
            emptyText.setText("No weight entries yet");
            emptyText.setPadding(24, 24, 24, 24);
            emptyRow.addView(emptyText);
            tableWeights.addView(emptyRow);
            return;
        }

        for (WeightEntry entry : entries) {
            TableRow row = new TableRow(this);
            row.setLayoutParams(new TableLayout.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT,
                    ViewGroup.LayoutParams.WRAP_CONTENT
            ));

            TextView dateCell = createTextCell(entry.getEntryDate(), 2f);
            TextView weightCell = createTextCell(String.format(Locale.US, "%.1f", entry.getWeightValue()), 1f);

            Button editButton = createActionButton("Edit");
            editButton.setOnClickListener(v -> openEditWeightScreen(entry));

            Button deleteButton = createActionButton("Delete");
            deleteButton.setOnClickListener(v -> {
                databaseHelper.deleteWeightEntry(entry.getId());
                populateWeightTable();
                Toast.makeText(this, "Weight entry deleted.", Toast.LENGTH_SHORT).show();
            });

            row.addView(dateCell);
            row.addView(weightCell);
            row.addView(editButton);
            row.addView(deleteButton);

            tableWeights.addView(row);
        }
    }

    private TextView createTextCell(String value, float weight) {
        TextView textView = new TextView(this);
        TableRow.LayoutParams params = new TableRow.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, weight);
        textView.setLayoutParams(params);
        textView.setPadding(16, 16, 16, 16);
        textView.setText(value);
        return textView;
    }

    private Button createActionButton(String text) {
        Button button = new Button(this);
        TableRow.LayoutParams params = new TableRow.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f);
        params.setMargins(4, 8, 4, 8);
        button.setLayoutParams(params);
        button.setText(text);
        button.setGravity(Gravity.CENTER);
        return button;
    }
}