package com.zybooks.weightogoprojecttwo;

/**
 * Simple model class for one saved daily weight entry.
 */
public class WeightEntry {
    private final int id;
    private final String entryDate;
    private final double weightValue;

    public WeightEntry(int id, String entryDate, double weightValue) {
        this.id = id;
        this.entryDate = entryDate;
        this.weightValue = weightValue;
    }

    public int getId() {
        return id;
    }

    public String getEntryDate() {
        return entryDate;
    }

    public double getWeightValue() {
        return weightValue;
    }
}