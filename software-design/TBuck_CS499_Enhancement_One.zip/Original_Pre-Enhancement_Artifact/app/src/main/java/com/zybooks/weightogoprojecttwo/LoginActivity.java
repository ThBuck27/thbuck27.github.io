package com.zybooks.weightogoprojecttwo;

import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

/**
 * Handles user login and first-time account creation.
 */
public class LoginActivity extends AppCompatActivity {

    private EditText editUsername;
    private EditText editPassword;
    private DatabaseHelper databaseHelper;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        databaseHelper = new DatabaseHelper(this);

        editUsername = findViewById(R.id.editUsername);
        editPassword = findViewById(R.id.editPassword);
        Button buttonLogin = findViewById(R.id.buttonLogin);
        Button buttonCreateAccount = findViewById(R.id.buttonCreateAccount);

        buttonLogin.setOnClickListener(v -> attemptLogin());
        buttonCreateAccount.setOnClickListener(v -> attemptCreateAccount());
    }

    private void attemptLogin() {
        String username = editUsername.getText().toString().trim();
        String password = editPassword.getText().toString().trim();

        if (TextUtils.isEmpty(username) || TextUtils.isEmpty(password)) {
            Toast.makeText(this, "Enter both username and password.", Toast.LENGTH_SHORT).show();
            return;
        }

        if (databaseHelper.validateUser(username, password)) {
            openDashboard(username);
        } else {
            Toast.makeText(this, "Login failed. Check your username and password.", Toast.LENGTH_SHORT).show();
        }
    }

    private void attemptCreateAccount() {
        String username = editUsername.getText().toString().trim();
        String password = editPassword.getText().toString().trim();

        if (TextUtils.isEmpty(username) || TextUtils.isEmpty(password)) {
            Toast.makeText(this, "Enter both username and password.", Toast.LENGTH_SHORT).show();
            return;
        }

        boolean created = databaseHelper.registerUser(username, password);
        if (created) {
            Toast.makeText(this, "Account created successfully.", Toast.LENGTH_SHORT).show();
            openDashboard(username);
        } else {
            Toast.makeText(this, "That username already exists.", Toast.LENGTH_SHORT).show();
        }
    }

    private void openDashboard(String username) {
        Intent intent = new Intent(this, DashboardActivity.class);
        intent.putExtra("USERNAME", username);
        startActivity(intent);
    }
}